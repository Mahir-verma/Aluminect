<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'alumni') {
    header("Location: index.html");
    exit();
}

$passing_year = $_SESSION['passing_year']; // Assuming this is set at login
$conn = new mysqli("localhost", "root", "", "alumnium_connecto");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, email FROM users WHERE passing_year = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $passing_year);
$stmt->execute();
$result = $stmt->get_result();

$batchmates = [];
while ($row = $result->fetch_assoc()) {
    $batchmates[] = $row;
}

$stmt->close();
$conn->close();

header("Content-Type: application/json");
echo json_encode($batchmates);
?>
