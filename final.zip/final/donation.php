<?php
// Start the session (if needed for user identification)
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $amount = $_POST['amount'];
    $cause = $_POST['cause'];
    $email = isset($_SESSION['email']) ? $_SESSION['email'] : 'guest'; // Use session email or 'guest' if not logged in

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = ""; // XAMPP default password
    $dbname = "alumnium_connecto";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL query to insert donation details
    $sql = "INSERT INTO donations (email, amount, cause) VALUES ('$email', '$amount', '$cause')";

    // Check if donation was inserted successfully
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Donation successful! Thank you for your contribution.'); window.location.href = 'donation.html';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>
