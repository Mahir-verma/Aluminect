<?php
session_start();

// Check if the user is logged in and is alumni
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'alumni') {
    header("Location: index.html"); // Redirect to login page
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = ""; // Default XAMPP MySQL password
$dbname = "alumnium_connecto";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the current announcement content
$announcementContent = '';
$sql = "SELECT content FROM announcements WHERE id = 1"; // Assuming single announcement
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $announcementContent = $row['content'];
} else {
    $announcementContent = 'No announcement available at the moment.';
}

// Fetch events data from the database
$events = [];
$sqlEvents = "SELECT event_name, event_date, description FROM events"; // Modify this based on your table structure
$resultEvents = $conn->query($sqlEvents);

if ($resultEvents->num_rows > 0) {
    while ($row = $resultEvents->fetch_assoc()) {
        $events[] = $row; // Store each event in the $events array
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Front Page</title>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Header */
        header .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #333;
            color: #fefbfb;
        }

        header .college-logo img {
            width: 60px;
            height: auto;
        }

        header .college-name {
            font-size: 18px;
            font-weight: bold;
        }

        header .box a {
            text-decoration: none;
            color: #1e90ff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        header .box a:hover {
            color: #ff4500;
        }

        header .search-bar {
            padding: 5px;
            border-radius: 5px;
            border: none;
        }

        /* Exclusives Text Blinking in RGB */
        @keyframes blinkRGB {
            0% { color: red; }
            25% { color: green; }
            50% { color: blue; }
            75% { color: yellow; }
            100% { color: magenta; }
        }

        header .exclusives {
            position: relative;
            display: inline-block;
            cursor: pointer;
            padding: 10px;
            font-size: 16px;
            font-weight: bold;
            animation: blinkRGB 2s infinite; /* Apply the RGB animation */
        }

        header .exclusives-content {
            display: none;
            position: absolute;
            background-color: #333;
            min-width: 160px;
            z-index: 1;
            border-radius: 5px;
        }

        header .exclusives-content a {
            color: white;
            padding: 10px 20px;
            display: block;
            text-decoration: none;
        }

        header .exclusives-content a:hover {
            background-color: #555;
            color: #ffcc00;
        }

        header .exclusives:hover .exclusives-content {
            display: block;
        }

        /* Photo Collage Section */
        .photo-collage {
            height: 400px;
            background-image: url('ccet.jpeg');
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            text-align: center;
        }

        .photo-collage h1 {
            font-size: 36px;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }

        /* Content Section */
        .content-section {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px 0;
            padding: 20px;
            background-color: #ccc;
        }

        .content-section .box-content {
            text-align: center;
            border: 2px solid #f6f4f4;
            padding: 20px;
            width: 300px;
            background-color: #333;
            border-radius: 10px;
        }

        .content-section h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #f8f3f3;
        }

        .content-section .box-content h3,
        .content-section .box-content p {
            color: white; /* Text color for event contents set to white */
        }

        .announcement-box {
            text-align: center;
            margin-top: 20px;
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            color: white;
        }

        /* Footer */
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="college-logo"><img src="collegelogo.jpg" alt="College Logo"></div>
            <div class="college-name">Chandigarh College of Engineering and Technology</div>
            <div class="box"><a href="indexfrontpageafterlogin.html">Home</a></div>
            <div class="box">
                <input type="text" placeholder="Search..." class="search-bar">
            </div>
            <div class="box">
                <div class="exclusives">
                    Exclusives
                    <div class="exclusives-content">
                        <a href="workshop.php">Workshops</a>
                        <a href="meetups.php">Meetups</a>
                        <a href="#">Entrepreneurship</a>
                        <a href="#">Career Guidance</a>
                        <a href="#">Interact with Batchmates</a>
                    </div>
                </div>
            </div>
            <div class="box"><a href="qna.php">QnA</a></div>
            <div class="box"><a href="donation.html">Donation Portal</a></div>
            <div class="profile-circle">
                <a href="profilepage.php"><span class="profile">Profile</span></a>
            </div>
        </div>
    </header>

    <section class="photo-collage">
        <div class="collage-container">
            <h1>Welcome Our Alumni</h1>
        </div>
    </section>

    <section class="content-section">
        <div class="box-content">
            <h2>Events</h2>
            <?php if (count($events) > 0): ?>
                <?php foreach ($events as $event): ?>
                    <div>
                        <h3><?php echo htmlspecialchars($event['event_name']); ?></h3>
                        <p><strong>Date:</strong> <?php echo htmlspecialchars($event['event_date']); ?></p>
                        <p><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No upcoming events.</p>
            <?php endif; ?>
        </div>

        <div class="box-content">
            <h2>Announcements</h2>
            <div class="announcement-box">
                <p><?php echo nl2br(htmlspecialchars($announcementContent)); ?></p>
            </div>
        </div>
    </section>

    <footer class="footer">
        <p>&copy; 2024 Chandigarh College of Engineering and Technology. All rights reserved.</p>
    </footer>
</body>
</html>
