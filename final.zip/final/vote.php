<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alumnium_connecto";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vote_type']) && isset($_POST['answer_id'])) {
    $vote_type = $_POST['vote_type']; // 'up' or 'down'
    $answer_id = $_POST['answer_id'];
    $user_email = $_SESSION['email'];

    // Check if the user has already voted for this answer
    $sql = "SELECT * FROM votes WHERE answer_id = '$answer_id' AND user_email = '$user_email'";
    $result = $conn->query($sql);

    if ($result->num_rows === 0) {
        // Insert the vote if the user hasn't voted yet
        $sql = "INSERT INTO votes (answer_id, vote_type, user_email) VALUES ('$answer_id', '$vote_type', '$user_email')";
        $conn->query($sql);
    }
}
?>
