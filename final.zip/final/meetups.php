<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'alumni') {
    header("Location: index.html");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alumnium_connecto";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert a new meetup
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['createMeetup'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $stmt = $conn->prepare("INSERT INTO meetups (title, description, date, time, upvotes) VALUES (?, ?, ?, ?, 0)");
    $stmt->bind_param("ssss", $title, $description, $date, $time);

    if ($stmt->execute()) {
        $message = "Meetup created successfully!";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch all meetups
$meetups = [];
$sql = "SELECT id, title, description, date, time, upvotes FROM meetups ORDER BY upvotes DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $meetups[] = $row;
    }
}

// Upvote a meetup
if (isset($_GET['upvote'])) {
    $meetupId = $_GET['upvote'];
    $conn->query("UPDATE meetups SET upvotes = upvotes + 1 WHERE id = $meetupId");
    header("Location: meetups.php");
    exit();
}

// Add a chat message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addMessage'])) {
    $meetupId = $_POST['meetupId'];
    $message = $_POST['message'];
    $userEmail = $_SESSION['email'];

    $stmt = $conn->prepare("INSERT INTO meetup_chats (meetup_id, user_email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $meetupId, $userEmail, $message);

    if (!$stmt->execute()) {
        $chatError = "Error adding message: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch chat messages for a specific meetup
function getChatMessages($conn, $meetupId) {
    $messages = [];
    $stmt = $conn->prepare("SELECT user_email, message, created_at FROM meetup_chats WHERE meetup_id = ? ORDER BY created_at ASC");
    $stmt->bind_param("i", $meetupId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    $stmt->close();
    return $messages;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meetups</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .meetup-form input,
        .meetup-form textarea,
        .meetup-form button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .meetup-form button {
            background: #5cb85c;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .meetup-form button:hover {
            background: #4cae4c;
        }

        .meetup-card {
            padding: 15px;
            border: 1px solid #ccc;
            margin: 10px 0;
            border-radius: 5px;
            background: #f9f9f9;
        }

        .meetup-card h3 {
            margin: 0;
        }

        .meetup-card .details {
            font-size: 14px;
            color: #666;
        }

        .upvote-button,
        .chat-toggle-button {
            padding: 5px 10px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-right: 5px;
        }

        .upvote-button:hover,
        .chat-toggle-button:hover {
            background: #0056b3;
        }

        .chat-section {
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #f7f7f7;
        }

        .chat-messages {
            max-height: 150px;
            overflow-y: auto;
            margin-bottom: 10px;
        }

        .chat-messages div {
            margin: 5px 0;
            padding: 5px;
            background: #e9e9e9;
            border-radius: 5px;
        }

        .chat-form input,
        .chat-form button {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 5px;
        }

        .chat-form button {
            background: #5cb85c;
            color: white;
        }

        .chat-form button:hover {
            background: #4cae4c;
        }

        .back-to-home {
            margin: 20px 0;
            text-align: center;
        }

        .back-home-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .back-home-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Plan a Meetup</h1>
        </div>

        <!-- Form to create a meetup -->
        <form class="meetup-form" method="POST">
            <input type="text" name="title" placeholder="Meetup Title" required>
            <textarea name="description" rows="4" placeholder="Description" required></textarea>
            <input type="date" name="date" required>
            <input type="time" name="time" required>
            <button type="submit" name="createMeetup">Create Meetup</button>
        </form>

        <!-- Back to Home Button -->
        <div class="back-to-home">
            <a href="alumnifrontpage.php" class="back-home-button">Back to Home</a>
        </div>

        <hr>

        <h2>Upcoming Meetups</h2>

        <?php foreach ($meetups as $meetup): ?>
            <div class="meetup-card">
                <h3><?php echo htmlspecialchars($meetup['title']); ?></h3>
                <p class="details">
                    Date: <?php echo htmlspecialchars($meetup['date']); ?> | 
                    Time: <?php echo htmlspecialchars($meetup['time']); ?>
                </p>
                <p><?php echo nl2br(htmlspecialchars($meetup['description'])); ?></p>
                <p>Upvotes: <?php echo $meetup['upvotes']; ?></p>
                <a href="?upvote=<?php echo $meetup['id']; ?>" class="upvote-button">Upvote</a>
                <a href="#" class="chat-toggle-button" onclick="toggleChat(<?php echo $meetup['id']; ?>)">Chat</a>

                <!-- Chat Section -->
                <div class="chat-section" id="chat-<?php echo $meetup['id']; ?>" style="display: none;">
                    <div class="chat-messages">
                        <?php $messages = getChatMessages($conn, $meetup['id']); ?>
                        <?php foreach ($messages as $message): ?>
                            <div>
                                <strong><?php echo htmlspecialchars($message['user_email']); ?>:</strong>
                                <p><?php echo htmlspecialchars($message['message']); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <form class="chat-form" method="POST">
                        <input type="hidden" name="meetupId" value="<?php echo $meetup['id']; ?>">
                        <input type="text" name="message" placeholder="Type your message..." required>
                        <button type="submit" name="addMessage">Send</button>
                    </form>

                    <?php if (isset($chatError)) echo "<p style='color:red;'>$chatError</p>"; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (empty($meetups)) echo "<p>No meetups available. Plan one now!</p>"; ?>
    </div>

    <script>
        function toggleChat(meetupId) {
            const chatSection = document.getElementById('chat-' + meetupId);
            chatSection.style.display = chatSection.style.display === 'none' ? 'block' : 'none';
        }
    </script>
</body>
</html>
