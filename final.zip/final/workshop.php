<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['email'])) {
    header("Location: index.html");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alumnium_connecto";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch workshops data
$workshops = [];
$sql = "SELECT id, title, description FROM workshops"; // Assuming a workshops table exists
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $workshops[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Workshops</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        header {
            padding: 10px 20px;
            background-color: #333;
            color: white;
            text-align: center;
        }

        .workshop-container {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .workshop-card {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 300px;
            width: 100%;
        }

        .workshop-card h3 {
            margin: 0 0 10px;
        }

        .workshop-card p {
            color: #555;
        }

        .join-button {
            display: inline-block;
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }

        .join-button:hover {
            background-color: #45a049;
        }

        .back-home-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 20px;
            display: block;
            text-align: center;
        }

        .back-home-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <h1>Interactive Workshops</h1>
    </header>

    <div class="workshop-container">
        <?php if (count($workshops) > 0): ?>
            <?php foreach ($workshops as $workshop): ?>
                <div class="workshop-card">
                    <h3><?php echo htmlspecialchars($workshop['title']); ?></h3>
                    <p><?php echo nl2br(htmlspecialchars($workshop['description'])); ?></p>
                    <a href="join_workshop.php?workshop_id=<?php echo $workshop['id']; ?>" class="join-button">Join</a>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No workshops available at the moment.</p>
        <?php endif; ?>
    </div>

    <!-- Back to Home Button -->
    <div class="back-home-button">
        <a href="alumnifrontpage.php" class="back-home-button">Back to Home</a>
    </div>
</body>
</html>
