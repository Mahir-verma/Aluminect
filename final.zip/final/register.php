<?php
// Database connection
$servername = "localhost";
$username = "root"; // Default XAMPP MySQL username
$password = ""; // Default XAMPP MySQL password (empty by default)
$dbname = "alumnium_connecto"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted for Student Registration
if (isset($_POST['verifyStudent'])) {
    // Student registration data
    $emailOrCollegeId = $_POST['emailOrCollegeId'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];

    // Validate required fields
    if (empty($emailOrCollegeId) || empty($password) || empty($phone)) {
        echo "All fields are required.";
        exit();
    }

    // Insert student data into the students table (without student_id as it's auto-increment)
    $sql = "INSERT INTO students (email, password, phone) 
            VALUES (?, ?, ?)";

    // Prepare and bind
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sss", $emailOrCollegeId, $password, $phone);

        // Execute the query
        if ($stmt->execute()) {
            echo "Student registration successful!";
            echo '<br>';
            echo '<a href="index.html" class="btn">Continue to Login</a>';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}
// Check if the form is submitted for Alumni Registration
elseif (isset($_POST['verifyAlumni'])) {
    // Alumni registration data
    $emailOrCollegeId = $_POST['emailOrCollegeId'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];
    $college = $_POST['college'];
    $year = $_POST['year'];  // Alumni passing year

    // Validate required fields
    if (empty($emailOrCollegeId) || empty($password) || empty($phone) || empty($course) || empty($college) || empty($year)) {
        echo "All fields are required.";
        exit();
    }

    // Insert alumni data into the alumni table
    $sql = "INSERT INTO alumni (email, password, phone, course, college, year) 
            VALUES (?, ?, ?, ?, ?, ?)";

    // Prepare and bind
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sssssi", $emailOrCollegeId, $password, $phone, $course, $college, $year);

        // Execute the query
        if ($stmt->execute()) {
            echo "Alumni registration successful!";
            echo '<br>';
            echo '<a href="index.html" class="btn">Continue to Login</a>';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}
// Check if the form is submitted for Faculty Registration
elseif (isset($_POST['verifyFaculty'])) {
    // Faculty registration data
    $emailOrCollegeId = $_POST['emailOrCollegeId'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $officialEmail = $_POST['officialEmail'];

    // Validate required fields
    if (empty($emailOrCollegeId) || empty($password) || empty($phone) || empty($officialEmail)) {
        echo "All fields are required.";
        exit();
    }

    // Insert faculty data into the faculty table
    $sql = "INSERT INTO faculty (email, password, phone, official_email) 
            VALUES (?, ?, ?, ?)";

    // Prepare and bind
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssss", $emailOrCollegeId, $password, $phone, $officialEmail);

        // Execute the query
        if ($stmt->execute()) {
            echo "Faculty registration successful!";
            echo '<br>';
            echo '<a href="index.html" class="btn">Continue to Login</a>';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>