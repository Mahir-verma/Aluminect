<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";  // Default username for XAMPP
$password = "";  // Default password for XAMPP
$dbname = "alumnium_connecto";  // Correct database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];

    // Based on the selected role, verify the user
    if ($role == "student") {
        // Query to check student credentials
        $sql = "SELECT * FROM students WHERE email = ? AND password = ? AND phone = ?";
    } elseif ($role == "alumni") {
        // Query to check alumni credentials
        $sql = "SELECT * FROM alumni WHERE email = ? AND password = ? AND phone = ?";
    } elseif ($role == "faculty") {
        // Query to check faculty credentials
        $sql = "SELECT * FROM faculty WHERE email = ? AND password = ? AND phone = ?";
    } else {
        echo "Invalid role.";
        exit();
    }

    // Prepare and execute the query
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sss", $email, $password, $phone);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if any matching record was found
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            // Store user details in session
            $_SESSION['user_id'] = $row['id'];  // Assuming 'id' is the primary key in the database
            $_SESSION['email'] = $row['email'];
            $_SESSION['phone'] = $row['phone'];
            $_SESSION['role'] = $role;
            
            // Redirect to the respective front page based on role
            if ($role == "student") {
                header("Location: studentfrontpage.php");  // Redirect to student front page
            } elseif ($role == "alumni") {
                header("Location: alumnifrontpage.php");  // Redirect to alumni front page
            } elseif ($role == "faculty") {
                header("Location: facultyfrontpage.php");  // Redirect to faculty front page
            }
            exit();
        } else {
            echo "Invalid credentials or role. Please try again.";
            echo '<br>';
            echo '<a href="index.html" class="btn">Continue to Login</a>';
        }

        // Close statement
        $stmt->close();
    }
}

// Close connection
$conn->close();
?>
