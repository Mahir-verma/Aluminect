<?php
session_start();

// Check if the user is logged in and is faculty
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'faculty') {
    header("Location: index.html"); // Redirect to login page
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = ""; // Default XAMPP MySQL password
$dbname = "alumnium_connecto";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the current announcement content
$announcementContent = '';
$sql = "SELECT content FROM announcements WHERE id = 1"; // Assuming single announcement
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $announcementContent = $row['content'];
} else {
    // Insert a default announcement if none exists
    $sql = "INSERT INTO announcements (content) VALUES ('Default announcement content.')";
    $conn->query($sql);
    $announcementContent = 'Default announcement content.';
}

// Update announcement if form is submitted
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['announcement'])) {
        // Update announcement content
        $newAnnouncement = $conn->real_escape_string($_POST['announcement']);
        $sql = "UPDATE announcements SET content = '$newAnnouncement' WHERE id = 1";
        if ($conn->query($sql) === TRUE) {
            $announcementContent = $newAnnouncement;
            $message = "Announcement updated successfully!";
        } else {
            $message = "Error updating announcement: " . $conn->error;
        }
    } elseif (isset($_POST['event_title'])) {
        // Add a new event
        $eventTitle = $conn->real_escape_string($_POST['event_title']);
        $eventDate = $conn->real_escape_string($_POST['event_date']);
        $eventDescription = $conn->real_escape_string($_POST['event_description']);
        $sql = "INSERT INTO events (event_name, event_date, description) VALUES ('$eventTitle', '$eventDate', '$eventDescription')";
        if ($conn->query($sql) === TRUE) {
            $message = "Event added successfully!";
        } else {
            $message = "Error adding event: " . $conn->error;
        }
    }
}

// Fetch recent suggestions
$suggestions = [];
$sqlSuggestions = "SELECT student_email, suggestion_text, submission_date FROM suggestions ORDER BY submission_date DESC LIMIT 5";
$resultSuggestions = $conn->query($sqlSuggestions);

if ($resultSuggestions->num_rows > 0) {
    while ($row = $resultSuggestions->fetch_assoc()) {
        $suggestions[] = $row;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Announcements & Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url("study5.jpg") no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }

        header {
            background-color: #333;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        header .college-logo img {
            width: 60px;
            height: auto;
        }

        header .college-name {
            color: #fff;
            font-size: 18px;
            font-weight: bold;
        }

        header a {
            color: #fff;
            text-decoration: none;
            margin-left: 20px;
        }

        main {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            color: #333;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .message {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        textarea {
            width: 100%;
            height: 150px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #555;
        }

        footer {
            text-align: center;
            margin-top: 30px;
            color: #fff;
        }

        .content-section {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
        }

        .box-content {
            margin-bottom: 20px;
            width: 48%;
        }

        .box-content h3 {
            margin: 0 0 10px;
        }

        .box-content p {
            margin: 0;
        }

        .recent-suggestions ul {
            list-style-type: none;
            padding: 0;
        }

        .recent-suggestions ul li {
            background-color: #f9f9f9;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header>
        <div class="college-logo">
            <img src="collegelogo.jpg" alt="College Logo">
        </div>
        <div class="college-name">Chandigarh College of Engineering and Technology</div>
        <div>
            <a href="indexfrontpageafterlogin.html">Home</a>
            <a href="qna.php">QnA</a>
            <a href="profilepage.php">Profile</a>
        </div>
    </header>

    <main>
        <h1>Manage Announcements & Events</h1>

        <?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

        <!-- Announcement Form -->
        <h2>Update Announcement</h2>
        <form method="POST" action="">
            <textarea name="announcement" required><?php echo htmlspecialchars($announcementContent); ?></textarea>
            <button type="submit">Update Announcement</button>
        </form>

        <!-- Event Form -->
        <h2>Add New Event</h2>
        <form method="POST" action="">
            <input type="text" name="event_title" placeholder="Event Title" required>
            <input type="date" name="event_date" required>
            <textarea name="event_description" placeholder="Event Description" required></textarea>
            <button type="submit">Add Event</button>
        </form>

        <!-- Event List -->
        <h2>Upcoming Events</h2>
        <div class="content-section">
            <?php
            // Fetch and display events
            $conn = new mysqli($servername, $username, $password, $dbname);
            $eventSql = "SELECT * FROM events ORDER BY event_date ASC"; // Adjusted query to match column names
            $eventResult = $conn->query($eventSql);

            if ($eventResult->num_rows > 0) {
                while ($eventRow = $eventResult->fetch_assoc()) {
                    echo "<div class='box-content'>";
                    echo "<h3>" . htmlspecialchars($eventRow['event_name']) . "</h3>";
                    echo "<p><strong>Date:</strong> " . htmlspecialchars($eventRow['event_date']) . "</p>";
                    echo "<p>" . htmlspecialchars($eventRow['description']) . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No upcoming events.</p>";
            }
            ?>
        </div>

        <!-- Recent Suggestions -->
        <h2>Recent Suggestions</h2>
        <div class="recent-suggestions">
            <ul>
                <?php if (count($suggestions) > 0): ?>
                    <?php foreach ($suggestions as $suggestion): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($suggestion['student_email']); ?>:</strong>
                            <p><?php echo nl2br(htmlspecialchars($suggestion['suggestion_text'])); ?></p>
                            <small>Submitted on: <?php echo htmlspecialchars($suggestion['submission_date']); ?></small>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No recent suggestions.</p>
                <?php endif; ?>
            </ul>
        </div>

    </main>

    <footer>
        <p>&copy; 2024 Alma Connect. All rights reserved.</p>
    </footer>
</body>
</html>
