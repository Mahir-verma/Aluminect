<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";

// Get sender, receiver IDs
$sender_id = $_SESSION['user_id'];
$receiver_id = $_POST['receiver_id'];

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch messages between two users
$sql = "SELECT sender_id, receiver_id, message, timestamp FROM messages WHERE 
       (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
       ORDER BY timestamp";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

$stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($messages);
?>
