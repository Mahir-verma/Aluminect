<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: index.html");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alumnium_connecto";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['workshop_id'])) {
    $workshop_id = intval($_GET['workshop_id']);
    $email = $_SESSION['email'];

    // Check if already joined
    $checkSql = "SELECT * FROM workshop_participants WHERE workshop_id = ? AND email = ?";
    $stmt = $conn->prepare($checkSql);
    $stmt->bind_param("is", $workshop_id, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "You have already joined this workshop!";
    } else {
        // Insert participation record
        $sql = "INSERT INTO workshop_participants (workshop_id, email) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $workshop_id, $email);

        if ($stmt->execute()) {
            echo "Successfully joined the workshop!";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
    $stmt->close();
}

$conn->close();
?>
