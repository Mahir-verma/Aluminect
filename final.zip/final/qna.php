<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alumnium_connecto";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Post a Question
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['question'])) {
    $question = $_POST['question'];
    $user_email = $_SESSION['email']; // Assuming the user is logged in

    $sql = "INSERT INTO questions (question, user_email) VALUES ('$question', '$user_email')";
    $conn->query($sql);
}

// Post an Answer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['answer']) && isset($_POST['question_id'])) {
    $answer = $_POST['answer'];
    $question_id = $_POST['question_id'];
    $user_email = $_SESSION['email'];

    $sql = "INSERT INTO answers (answer, user_email, question_id) VALUES ('$answer', '$user_email', '$question_id')";
    $conn->query($sql);
}

// Upvote/Downvote
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vote_type']) && isset($_POST['answer_id'])) {
    $vote_type = $_POST['vote_type']; // 'up' or 'down'
    $answer_id = $_POST['answer_id'];
    $user_email = $_SESSION['email'];

    // Check if the user has already voted for this answer
    $sql = "SELECT * FROM votes WHERE answer_id = '$answer_id' AND user_email = '$user_email'";
    $result = $conn->query($sql);

    if ($result->num_rows === 0) {
        // Insert the vote if the user hasn't voted yet
        $sql = "INSERT INTO votes (answer_id, vote_type, user_email) VALUES ('$answer_id', '$vote_type', '$user_email')";
        $conn->query($sql);
    }
}

// Fetch last 3 questions
$questions_sql = "SELECT * FROM questions ORDER BY created_at DESC LIMIT 3";
$questions_result = $conn->query($questions_sql);

// Fetch answers and vote counts for each answer
$answers_sql = "SELECT a.id as answer_id, a.answer, a.question_id, q.question, COUNT(v.id) AS upvotes, COUNT(DISTINCT v.id) AS downvotes
                FROM answers a
                LEFT JOIN questions q ON a.question_id = q.id
                LEFT JOIN votes v ON a.id = v.answer_id AND v.vote_type = 'up'
                LEFT JOIN votes v_down ON a.id = v_down.answer_id AND v_down.vote_type = 'down'
                GROUP BY a.id";
$answers_result = $conn->query($answers_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Q&A Section</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f1f1f1;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px 10px;
        }

        .qna-section {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background-color: #333;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .main-container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-top: 20px;
        }

        .ask-box, .reply-box {
            flex: 1;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        }

        textarea {
            width: 94%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            resize: none;
            height: 80px;
        }

        button {
            margin-top: 10px;
            padding: 10px;
            border: none;
            background-color: #007BFF;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .qa-list ul {
            list-style: none;
            padding: 0;
        }

        .qa-list li {
            margin-bottom: 15px;
            background-color: #f1f1f1;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .vote {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .answer-section {
            margin-top: 10px;
            padding: 10px;
            background-color: #333;
            border-radius: 5px;
        }

        .recent-answers {
            margin-top: 40px;
            background-color: #f1f1f1;
            padding: 20px;
            border-radius: 8px;
        }

        .recent-answers h3 {
            margin-top: 0;
        }
    </style>
    <script>
        function toggleDropdown(id) {
            const answerSection = document.getElementById(`answer-${id}`);
            const icon = document.getElementById(`arrow-${id}`);
            if (answerSection.style.display === "block") {
                answerSection.style.display = "none";
                icon.textContent = "▼";
            } else {
                answerSection.style.display = "block";
                icon.textContent = "▲";
            }
        }

        function vote(answer_id, type) {
            const countElement = document.getElementById(`${type}-count-${answer_id}`);
            let count = parseInt(countElement.textContent);
            countElement.textContent = type === "up" ? count + 1 : count - 1;

            // Send vote data to backend
            fetch('qna.php', {
                method: 'POST',
                body: new URLSearchParams({
                    'vote_type': type,
                    'answer_id': answer_id
                })
            });
        }
    </script>
</head>
<body>
    <header>
        <h1>Q&A Forum</h1>
    </header>

    <section class="qna-section">
        <h1>Q&A Forum</h1>

        <div class="main-container">
            <div class="ask-box">
                <h2>Ask a Question</h2>
                <form action="qna.php" method="POST">
                    <textarea name="question" placeholder="Type your question here..."></textarea>
                    <button type="submit">Post Question</button>
                </form>
            </div>

            <div class="reply-box">
                <h2>Reply to a Question</h2>
                <form action="qna.php" method="POST">
                    <h3>Select a Question to Answer</h3>
                    <select name="question_id">
                        <?php while ($question = $questions_result->fetch_assoc()): ?>
                            <option value="<?php echo $question['id']; ?>"><?php echo htmlspecialchars($question['question']); ?></option>
                        <?php endwhile; ?>
                    </select>
                    <textarea name="answer" placeholder="Type your reply here..."></textarea>
                    <button type="submit">Post Reply</button>
                </form>
            </div>
        </div>

        <div class="qa-list">
            <h2>Recent Questions</h2>
            <ul>
                <?php
                // Display the last 3 questions
                while ($question = $questions_result->fetch_assoc()):
                ?>
                    <li>
                        <div class="question">
                            <span onclick="toggleDropdown(<?php echo $question['id']; ?>)" class="dropdown-toggle"><?php echo htmlspecialchars($question['question']); ?></span>
                            <span class="vote">
                                <button onclick="vote(<?php echo $question['id']; ?>, 'up')">👍</button>
                                <span id="up-count-<?php echo $question['id']; ?>">0</span>
                                <button onclick="vote(<?php echo $question['id']; ?>, 'down')">👎</button>
                                <span id="down-count-<?php echo $question['id']; ?>">0</span>
                            </span>
                        </div>
                        <div id="answer-<?php echo $question['id']; ?>" class="answer-section" style="display: none;">
                            <?php
                            // Fetch answers for each question
                            $answer_sql = "SELECT * FROM answers WHERE question_id = " . $question['id'];
                            $answer_result = $conn->query($answer_sql);
                            while ($answer = $answer_result->fetch_assoc()):
                            ?>
                                <p><?php echo htmlspecialchars($answer['answer']); ?></p>
                            <?php endwhile; ?>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>

        <div class="recent-answers">
            <h3>Recent Answers</h3>
            <ul>
                <?php while ($answer = $answers_result->fetch_assoc()): ?>
                    <li>
                        <p><strong>Q: <?php echo htmlspecialchars($answer['question']); ?></strong></p>
                        <p>A: <?php echo htmlspecialchars($answer['answer']); ?></p>
                        <div class="vote">
                            <button onclick="vote(<?php echo $answer['answer_id']; ?>, 'up')">👍</button>
                            <span id="up-count-<?php echo $answer['answer_id']; ?>"><?php echo $answer['upvotes']; ?></span>
                            <button onclick="vote(<?php echo $answer['answer_id']; ?>, 'down')">👎</button>
                            <span id="down-count-<?php echo $answer['answer_id']; ?>"><?php echo $answer['downvotes']; ?></span>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>
    </section>
</body>
</html>

<?php
$conn->close();
?>
