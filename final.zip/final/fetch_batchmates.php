<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";

// Get the user's passing year from session
$passing_year = $_SESSION['passing_year'];

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query batchmates with the same passing year
$sql = "SELECT id, name, course, email FROM alumni WHERE passing_year = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $passing_year);
$stmt->execute();
$result = $stmt->get_result();

$batchmates = [];
while ($row = $result->fetch_assoc()) {
    $batchmates[] = $row;
}

$stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($batchmates);
?>
