<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alumnium_connecto";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    $userId = $_SESSION['user_id'];
    $role = $_SESSION['role'];

    // Fetch the user's data
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Query data from the respective table based on the role
        if ($role === 'student') {
            $sql = "SELECT * FROM students WHERE id = ?";
        } elseif ($role === 'alumni') {
            $sql = "SELECT * FROM alumni WHERE id = ?";
        } elseif ($role === 'faculty') {
            $sql = "SELECT * FROM faculty WHERE id = ?";
        } else {
            echo "Unknown role!";
            exit();
        }

        // Prepare and execute the query
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $userData = $result->fetch_assoc();
            } else {
                echo "No profile information found for user ID: $userId.";
                exit();
            }
        } else {
            echo "Error in SQL query: " . $conn->error;
            exit();
        }
    }

    // Update the user's data if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'] ?? '';
        $passingYear = $_POST['passingYear'] ?? '';

        // Update query based on the role
        if ($role === 'student') {
            $sql = "UPDATE students SET name = ?, passing_year = ? WHERE id = ?";
        } elseif ($role === 'alumni') {
            $sql = "UPDATE alumni SET name = ?, passing_year = ? WHERE id = ?";
        } elseif ($role === 'faculty') {
            $sql = "UPDATE faculty SET name = ?, passing_year = ? WHERE id = ?";
        }

        // Prepare and execute the update query
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("ssi", $name, $passingYear, $userId);
            if ($stmt->execute()) {
                $message = "Profile updated successfully!";
            } else {
                $message = "Error updating profile: " . $conn->error;
            }
        } else {
            $message = "Error in SQL query: " . $conn->error;
        }
    }

} else {
    echo "Please log in to view your profile.";
    header("Location: index.html");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <style>
        /* General body styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f7f6;
    margin: 0;
    padding: 0;
}

/* Header */
header {
    background-color: #2c3e50;
    color: #fff;
    text-align: center;
    padding: 20px 0;
}

header h1 {
    margin: 0;
    font-size: 2.5rem;
}

/* Profile Section */
.profile-section {
    width: 100%;
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.profile-section h2 {
    text-align: center;
    font-size: 1.8rem;
    color: #333;
    margin-bottom: 20px;
}

/* Form styling */
form {
    display: flex;
    flex-direction: column;
}

form label {
    font-size: 1rem;
    margin: 10px 0 5px;
    color: #333;
}

form input {
    padding: 12px;
    margin-bottom: 20px;
    font-size: 1rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: #f9f9f9;
    color: #333;
}

form input:focus {
    outline: none;
    border-color: #3498db;
    background-color: #eaf4fd;
}

/* Read-only inputs */
form input[readonly] {
    background-color: #f0f0f0;
    cursor: not-allowed;
}

/* Button styles */
button {
    background-color: #3498db;
    color: #fff;
    padding: 12px 20px;
    font-size: 1rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #2980b9;
}

/* Mobile responsiveness */
@media screen and (max-width: 768px) {
    header h1 {
        font-size: 2rem;
    }

    .profile-section {
        padding: 20px;
    }

    form input {
        font-size: 0.9rem;
    }
}

/* Styling for the Profile section */
.profile-section {
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    background-color: #ffffff;
}

/* Section for specific role fields (alumni, faculty) */
form .role-field {
    display: block;
}

/* Style for role-specific sections */
form .role-field input {
    background-color: #f9f9f9;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

header {
    background-color: #333;
    color: white;
    padding: 20px;
    text-align: center;
}

.profile-section {
    background-color: white;
    margin: 20px auto;
    padding: 20px;
    width: 80%;
    max-width: 600px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.profile-section h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

form {
    display: flex;
    flex-direction: column;
}

form label {
    margin-bottom: 8px;
    font-weight: bold;
    color: #333;
}

form input {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1rem;
}

form input[type="text"],
form input[type="email"],
form input[type="tel"],
form input[type="number"],
form input[type="date"] {
    width: 100%;
}

.update-button {
    padding: 12px;
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.update-button:hover {
    background-color: #45a049;
}

    </style>
</head>
<body>
    <header>
        <h1>Profile Page</h1>
    </header>
    <section class="profile-section">
        <h2>Your Profile</h2>

        <!-- Display success/error message -->
        <?php if (isset($message)) { ?>
            <div style="color: green; text-align: center;">
                <?php echo $message; ?>
            </div>
        <?php } ?>

        <form method="POST">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($userData['name'] ?? ''); ?>">

            <label for="email">Email:</label>
            <input type="email" id="email" value="<?php echo htmlspecialchars($userData['email']); ?>" readonly>

            <label for="phone">Phone:</label>
            <input type="tel" id="phone" value="<?php echo htmlspecialchars($userData['phone'] ?? ''); ?>" readonly>

            <!-- Passing Year Field -->
            <label for="passingYear">Passing Year:</label>
            <input type="text" id="passingYear" name="passingYear" value="<?php echo htmlspecialchars($userData['passing_year'] ?? ''); ?>">

            <button type="submit">Update Profile</button>
        </form>
    </section>
</body>
</html>
