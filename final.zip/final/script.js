document.getElementById('batchmatesBtn').addEventListener('click', () => {
    fetch('fetch_batchmates.php')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('batchmatesList');
            container.innerHTML = '';
            data.forEach(batchmate => {
                const div = document.createElement('div');
                div.classList.add('batchmate');
                div.innerHTML = `
                    <h3>${batchmate.name} (${batchmate.course})</h3>
                    <button onclick="openChat(${batchmate.id})">Chat</button>
                    <div id="chat-${batchmate.id}" class="chat-window" style="display:none;"></div>
                `;
                container.appendChild(div);
            });
        });
});

function openChat(batchmateId) {
    const chatWindow = document.getElementById(`chat-${batchmateId}`);
    chatWindow.style.display = 'block';
    fetch('fetch_messages.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiver_id: batchmateId })
    })
        .then(response => response.json())
        .then(messages => {
            chatWindow.innerHTML = messages.map(msg => `
                <p><strong>${msg.sender_id === sessionStorage.getItem('user_id') ? 'You' : 'Them'}:</strong> ${msg.message}</p>
            `).join('') + `
                <textarea id="msg-${batchmateId}"></textarea>
                <button onclick="sendMessage(${batchmateId})">Send</button>
            `;
        });
}

function sendMessage(batchmateId) {
    const message = document.getElementById(`msg-${batchmateId}`).value;
    fetch('send_message.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiver_id: batchmateId, message })
    }).then(() => {
        openChat(batchmateId); // Refresh chat
    });
}
