<?php
session_start();

// Check if the user is logged in and is a student
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = ""; // Default XAMPP MySQL password
$dbname = "alumnium_connecto";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle suggestion submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['suggestion'])) {
    $studentEmail = $_SESSION['email']; // Assuming the session has the student's email
    $suggestionText = $conn->real_escape_string($_POST['suggestion']); // Sanitize input

    // Insert suggestion into the database
    $sql = "INSERT INTO suggestions (student_email, suggestion_text) VALUES ('$studentEmail', '$suggestionText')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Suggestion submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error submitting suggestion: " . $conn->error . "');</script>";
    }
}

// Fetch the current announcement content
$announcementContent = '';
$sql = "SELECT content FROM announcements WHERE id = 1"; // Assuming single announcement
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $announcementContent = $row['content'];
} else {
    $announcementContent = 'No announcement available at the moment.';
}

// Fetch upcoming events
$events = [];
$sqlEvents = "SELECT event_name, event_date, description FROM events"; // Modify based on your structure
$resultEvents = $conn->query($sqlEvents);

if ($resultEvents->num_rows > 0) {
    while ($row = $resultEvents->fetch_assoc()) {
        $events[] = $row;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Section</title>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
        }

        header .college-logo img {
            width: 60px;
            height: auto;
        }

        header .college-name {
            font-size: 18px;
            font-weight: bold;
        }

        header .box {
            margin: 0 10px;
        }

        header .search-bar {
            padding: 5px;
            border-radius: 5px;
            border: none;
        }

        header .profile-circle {
            background-color: #fcfbfb;
            border-radius: 50%;
            padding: 10px;
        }

        header .profile-circle a {
            color: #070707;
            text-decoration: none;
            font-size: 14px;
        }

        /* Main Content Section */
        .main-content {
            display: flex;
            gap: 20px; /* Space between left and right sections */
            padding: 20px;
        }

        /* Photo Collage Section (Left Side) */
        .photo-collage {
            flex: 1; /* Occupy 1/3 of the space */
        }

        .photo-collage .collage-container img {
            width: 100%;
            height: 620px;
            border-radius: 10px;
            object-fit: cover;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        /* Right Content Section (Right Side) */
        .right-content {
            flex: 2; /* Occupy 2/3 of the space */
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .right-content .box-content {
            background-color: #f9f9f9;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .right-content .box-content h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        .right-content .box-content p {
            font-size: 16px;
            color: #555;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }

            .photo-collage,
            .right-content {
                flex: 1;
            }
        }

        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 15px 0;
            margin-top: auto;
        }
        .container .box a{
            text-decoration: none;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="college-logo">
                <a href="indexfrontpage.html">
                    <img src="collegelogo.jpg" alt="College Logo"></a>
            </div>
            <div class="college-name">Chandigarh College of Engineering and Technology</div>
            <div class="profile-circle">
                <span class="profile"><a href="profilepage.php">Profile</a></span>
            </div>
        </div>
    </header>

    <!-- Main Content Section -->
    <section class="main-content">
        <!-- Left Side: Photo Collage -->
        <div class="photo-collage">
            <div class="collage-container">
                <img src="study1.jpg" alt="Photo Collage">
            </div>
        </div>

        <!-- Right Side: Events, Announcements, and Suggestion Box -->
        <div class="right-content">
            <!-- Events Box -->
            <div class="box-content">
                <h2>Events</h2>
                <?php if (count($events) > 0): ?>
                    <?php foreach ($events as $event): ?>
                        <div>
                            <h3><?php echo htmlspecialchars($event['event_name']); ?></h3>
                            <p><strong>Date:</strong> <?php echo htmlspecialchars($event['event_date']); ?></p>
                            <p><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No upcoming events.</p>
                <?php endif; ?>
            </div>

            <!-- Announcements Box -->
            <div class="box-content">
                <h2>Announcements</h2>
                <div class="announcement-box">
                    <p><?php echo nl2br(htmlspecialchars($announcementContent)); ?></p>
                </div>
            </div>

            <!-- Suggestion Box Form -->
            <div class="box-content">
                <h2>Suggestion Box</h2>
                <form action="studentfrontpage.php" method="POST">
                    <textarea name="suggestions" rows="4" cols="50" placeholder="Enter your suggestion here..."></textarea><br><br>
                    <input type="submit" value="Submit Suggestion">
                </form>
            </div>

            <div class="box-content">
                <h2><a href="qna.php">QnA</a></h2>
                <p>Get answers from expert.</p>
            </div>
        </div>
    </section>

    <footer class="footer">
        <p>&copy; 2024 Alma Connect. All rights reserved.</p>
    </footer>
</body>
</html>
